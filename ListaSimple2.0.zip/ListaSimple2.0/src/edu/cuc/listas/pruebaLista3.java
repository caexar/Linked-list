/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.listas;

/**
 *
 * @author cceveric
 */
public class pruebaLista3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ListaSimple<Double> listaReales = new ListaSimple<>();
        listaReales.adicionarAlInicio(3.0);
        listaReales.adicionarAlInicio(6.0);
        listaReales.adicionarAlInicio(9.0);
        System.out.println(listaReales);
        //eliminar
        System.out.println("eliminar 1: "+listaReales.eliminarAlInicio());
        System.out.println(listaReales);
        System.out.println("eliminar posicion 3: "+listaReales.eliminar(6.0));
        System.out.println(listaReales);
    }
    
}
