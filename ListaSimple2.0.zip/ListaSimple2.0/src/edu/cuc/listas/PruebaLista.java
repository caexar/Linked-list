/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.listas;

/**
 *
 * @author cceveric
 */
public class PruebaLista {
    public static void main(String[] args) {
        
        ListaSimple<String> listaCadena = new ListaSimple<>();
        System.out.println("lista: "+listaCadena);
        //adicionar
        listaCadena.adicionarAlInicio("hola");        
        listaCadena.adicionarAlInicio("hola2");
        listaCadena.adicionarAlInicio("hola3");
        System.out.println("lista: "+listaCadena);
        //buscar
        System.out.println("busqueda 1: "+listaCadena.buscar("hola2".toLowerCase()));
        //toLowerCase = para cambiar todas las cadena a minuscula
        
        
        
    }
    
}
