
package edu.cuc.cuentaBanco;

import edu.cuc.listas.ListaSimple;
import java.util.ArrayList;
import java.util.Objects;

public class MetodosCuenta {
    
    
    private String  nombre;
    private ListaSimple<Cuenta>listaCuenta = new ListaSimple<>();

    public MetodosCuenta(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    @Override
    public String toString() {
        return "MetodosCuenta{" + "nombre=" + nombre + ", listaCuenta=" + listaCuenta + '}';
    }
    
    //metodo adicionar
    public boolean adicionarCuenta(int numeroCuenta, double saldoCuenta, String titularCuenta){
        Cuenta cuentaNueva = new Cuenta(numeroCuenta, saldoCuenta, titularCuenta);
        listaCuenta.adicionarAlInicio(cuentaNueva);
        return true;
    }
    
    //metodo buscar
    public boolean buscarCuenta(int numeroCuenta) {
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (cuentaNueva.getNumeroCuenta() == numeroCuenta) {
                return true;
            }
        }
        return false;
    }
    
    //metodo eliminar
    public boolean eliminarCuenta(int numeroCuenta) {
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (cuentaNueva.getNumeroCuenta() == numeroCuenta) {
                return listaCuenta.eliminar(cuentaNueva);
            }
        }
        return false;
    }
    
    //metodo indicar la cuenta de un titular dado
    public ArrayList<Cuenta> indicarCuentaTitular(String titularCuenta) {
        ArrayList<Cuenta> resultado = new ArrayList<>();
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (cuentaNueva.getTitularCuenta().equalsIgnoreCase(titularCuenta)){
                resultado.add(cuentaNueva);
            }

        }
        return resultado;
    }
    
    //metodo indicar la cuenta de un numero de cuenta dado
    public ArrayList<Cuenta> indicarCuentaNumero(int numeroCuenta) {
        ArrayList<Cuenta> resultado = new ArrayList<>();
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (cuentaNueva.getNumeroCuenta() == (numeroCuenta)) {
                resultado.add(cuentaNueva);
            }

        }
        return resultado;
    }

    //indicar la cuenta por un saldo dado
        public ArrayList<Cuenta> indicarCuentaSaldo(double saldoCuenta) {
        ArrayList<Cuenta> resultado = new ArrayList<>();
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (cuentaNueva.getSaldoCuenta() == saldoCuenta) {
                resultado.add(cuentaNueva);
            }

        }
        return resultado;
    }
    

//    //metodo promedio del saldo de las cuentas.
    
    public Double indicarPromedioSaldo(){
        ArrayList<Cuenta> resultadousuario = new ArrayList<>();
        double promedio = 0.0;
        for (int i = 0; i < listaCuenta.longitud(); i++) {
        Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
        promedio += cuentaNueva.getSaldoCuenta();
        
        }
        
        return promedio = promedio / listaCuenta.longitud();
}
    
    //metodo indicar la cuenta con mayor saldo.
    public ArrayList<Cuenta> indicarMayorSaldo(){
        ArrayList<Cuenta> resultadousuario = new ArrayList<>();
        double numMayor = 0.0;
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (numMayor < cuentaNueva.getSaldoCuenta()) {
                numMayor = cuentaNueva.getSaldoCuenta();

            }
        }
        return indicarCuentaSaldo(numMayor);
    }
    
    //metodo indicar la cuenta con menor saldo.
    public ArrayList<Cuenta> indicarMenorSaldo(){
        ArrayList<Cuenta> resultadousuario = new ArrayList<>();
        double numMenor = 0.0;
        for (int i = 0; i < listaCuenta.longitud(); i++) {
             Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(0);
             numMenor = cuentaNueva.getSaldoCuenta();
        }
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (numMenor > cuentaNueva.getSaldoCuenta()) {
                numMenor = cuentaNueva.getSaldoCuenta();

            }
        }
        return indicarCuentaSaldo(numMenor);
    }
    
    
    //metodo que muestra todas las cuenta menos la que dice el usuario
    public ArrayList<Cuenta> indicarTodasMenosLaDada(int numeroCuenta) {
        ArrayList<Cuenta> resultado = new ArrayList<>();
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (cuentaNueva.getNumeroCuenta() == (numeroCuenta)) {
                
            }else{
             resultado.add(cuentaNueva);
            }

        }
        return resultado;
    }
    
    //metodo que elimine la cuenta con mayor saldo
    public boolean eliminarMayorSaldo() {
        ArrayList<Cuenta> resultadousuario = new ArrayList<>();
        double numMayor = 0.0;
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (numMayor < cuentaNueva.getSaldoCuenta()) {
                numMayor = cuentaNueva.getSaldoCuenta();
            }
            
        }
        //System.out.println(numMayor);
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (numMayor == cuentaNueva.getSaldoCuenta()) {
                listaCuenta.eliminar(cuentaNueva);
                return true;
            }
            
        }
        return false;
    }
    
    //metodo que elimine la cuenta con menor saldo
    public boolean eliminarMenorSaldo() {
        ArrayList<Cuenta> resultadousuario = new ArrayList<>();
        double numMenor = 0.0;
        for (int i = 0; i < listaCuenta.longitud(); i++) {
             Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(0);
             numMenor = cuentaNueva.getSaldoCuenta();
        }
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (numMenor > cuentaNueva.getSaldoCuenta()) {
                numMenor = cuentaNueva.getSaldoCuenta();
            }
        }
        System.out.println(numMenor);
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (numMenor == cuentaNueva.getSaldoCuenta()) {
                listaCuenta.eliminar(cuentaNueva);
                return true;
            }
            
        }
        return false;
    }
    
    //diga las cuentas que sean igual de dos banco
    public ArrayList<Cuenta> indicarIgualesDosBancos(MetodosCuenta banco02) {
        ArrayList<Cuenta> resultadousuario = new ArrayList<>();
        int numero01 = 0, numero02 =0, contador =0;

        for (int i = 0; i < listaCuenta.longitud(); i++) {
            contador++;
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            numero01 = cuentaNueva.getNumeroCuenta();

            for (int j = 0; j < banco02.listaCuenta.longitud(); j++) {
                numero02 = 0;
                Cuenta cuentaNueva2 = banco02.listaCuenta.buscarPorPosicion(j);
                numero02 = cuentaNueva2.getNumeroCuenta();
//                System.out.println(numero02);

                if (numero01 == numero02) {
                    resultadousuario.add(cuentaNueva2);

                    if (contador == listaCuenta.longitud()) {
                        return resultadousuario;

                    }
                }
            }

        }

        return resultadousuario;
    }
    
    //diga las cuentas que sean difente de dos banco
    public ArrayList<Cuenta> indicarDiferenteDosBancos(MetodosCuenta banco02) {
        ArrayList<Cuenta> arrayDiferente = new ArrayList<>();
        ArrayList<Cuenta> arrayIgual = new ArrayList<>();
        ArrayList<Cuenta> arrayResultado = new ArrayList<>();

        for (int i = 0; i < listaCuenta.longitud(); i++) {
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            for (int j = 0; j < banco02.listaCuenta.longitud(); j++) {
                Cuenta cuentaNueva2 = banco02.listaCuenta.buscarPorPosicion(j);
              //System.out.println("numero 1 es: "+cuentaNueva.getNumeroCuenta()+". numero 2 es: "+cuentaNueva2.getNumeroCuenta());

                if (cuentaNueva.getNumeroCuenta() != cuentaNueva2.getNumeroCuenta()) {
                    arrayDiferente.add(cuentaNueva);
                    arrayDiferente.add(cuentaNueva2);
                } else {
                    arrayIgual.add(cuentaNueva);
                }
            }
        }
        for (int i = 0; i < arrayDiferente.size(); i++) {
            for (int j = 0; j < arrayIgual.size(); j++) {
                if (arrayDiferente.get(i).equals(arrayIgual.get(j))) {
                    arrayDiferente.remove(i);
                }
            }
        }
        for (int i = 0; i < arrayDiferente.size(); i++) {
            if (arrayResultado.contains(arrayDiferente.get(i)) == false) {
                arrayResultado.add(arrayDiferente.get(i));
            }
        }return arrayResultado;
    }
    
    
    //indica/elimina las ultimas/primeras; mas de la mitad, menos de la mitad
    //indicar las ultimas y primer
    public String indicarUltimasyPrimeras(){
        ArrayList<Cuenta> arrayUltimos = new ArrayList<>();
        ArrayList<Cuenta> arrayPrimeros = new ArrayList<>();
        int contador =0;
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            contador++;
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (listaCuenta.longitud()/2 >= contador) {
                arrayUltimos.add(cuentaNueva);
            }else{
                arrayPrimeros.add(cuentaNueva);
            }
            
        }
        return "las ultimas cuenta son: "+arrayUltimos+" ...  y los primeros son: "+arrayPrimeros;
    }
    
    //indicar los ultimos datos de la cuenta
     public ArrayList<Cuenta> indicarUltima(){
        ArrayList<Cuenta> arrayUltimos = new ArrayList<>();
        ArrayList<Cuenta> arrayPrimeros = new ArrayList<>();
        int contador =0;
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            contador++;
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (listaCuenta.longitud()/2 >= contador) {
                arrayUltimos.add(cuentaNueva);
            }else{
                arrayPrimeros.add(cuentaNueva);
            }
            
        }
        return arrayUltimos;
    }
    
    //elimina las ultimas cuentas mitad para atras
    public boolean eliminarUltima(){
        int contador =0;
        int longitud = listaCuenta.longitud()/2;
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            contador++;
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (longitud >= contador) {
                listaCuenta.eliminarAlFinal();
            }
            
        }
        return true;
    }
    
     //elimina las primeras cuentas mitad para atras
    public boolean eliminarPrimeras(){
        int contador =0;
        int longitudT = listaCuenta.longitud();
        int longitud = longitudT / 2;
        for (int i = 0; i < longitudT; i++) {
            contador++;
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (longitud < contador) {
                listaCuenta.eliminarAlInicio();
            }
            if (contador == longitudT) {
                return true;
            }
        }
        return false;
    }
    
    //elimar las cuenta de un titular
    public boolean eliminarCuentaTitular(String titularCuenta) {
        for (int i = 0; i < listaCuenta.longitud(); i++) {

            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (cuentaNueva.getTitularCuenta().equalsIgnoreCase(titularCuenta)) {
                listaCuenta.eliminar(cuentaNueva);
                return true;
            }
        }
        return false;
    }
    
    //eliminar todas las cuenta de un titular
    public void eliminarCuentaTitularTodas(String titularCuenta){
        while (eliminarCuentaTitular(titularCuenta)) {
            
        }
    
    }
    
    //eliminar todas las cuenta de un titular v2
    public boolean eliminarCuentaTitularV2(String titularCuenta){
        int contador =0;
        int i = 0;;
        
        while(i < listaCuenta.longitud()){
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            
            if (cuentaNueva.getTitularCuenta().equalsIgnoreCase(titularCuenta)) {
                listaCuenta.eliminar(cuentaNueva);
                contador++;
                continue;
            }
            i++;
        }
        if (contador > 0) {
            return true;
        }return false;
    }
    
     //eliminar todas las cuenta de un saldo 
    public boolean eliminarCuentaSaldoV2(double saldoCuenta){
        int contador =0;
        int i = 0;
        
        while(i < listaCuenta.longitud()){
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            
            if (cuentaNueva.getSaldoCuenta() == saldoCuenta) {
                listaCuenta.eliminar(cuentaNueva);
                contador++;
                continue;
            }
            i++;
        }
        if (contador > 0) {
            return true;
        }return false;
    }
    
    //metodo eliminar por un rango de saldo dado por el usuario
      public boolean eliminarRangoSaldo(double min, double max){
        int contador =0;
        int i = 0;
        
        while(i < listaCuenta.longitud()){
            Cuenta cuentaNueva = listaCuenta.buscarPorPosicion(i);
            
            if (cuentaNueva.getSaldoCuenta() >= min && max >= cuentaNueva.getSaldoCuenta()) {
                listaCuenta.eliminar(cuentaNueva);
                contador++;
                continue;
            }
            i++;
        }
        if (contador > 0) {
            return true;
        }return false;
    }
    
    //metodo que cuente las veces consecutiva enque aparece un saldo o nombre del titular
      
    //metodo que indique si las cuentas son partidiaria
    //metodo que diga todas las cuenta que el titular inicie por la letra dada por el usuario
    
}
