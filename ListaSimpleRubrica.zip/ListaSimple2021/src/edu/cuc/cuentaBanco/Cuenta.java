/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.cuentaBanco;

import java.util.Objects;

/**
 *
 * @author slayk
 */
public class Cuenta {
    
    private int numeroCuenta;
    private double saldoCuenta;
    private String titularCuenta;

    public Cuenta(int numeroCuenta, double saldoCuenta, String titularCuenta) {
        this.numeroCuenta = numeroCuenta;
        this.saldoCuenta = saldoCuenta;
        this.titularCuenta = titularCuenta;
    }

    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(int numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public double getSaldoCuenta() {
        return saldoCuenta;
    }

    public String getTitularCuenta() {
        return titularCuenta;
    }

    public void setTitularCuenta(String titularCuenta) {
        this.titularCuenta = titularCuenta;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 47 * hash + this.numeroCuenta;
        hash = 47 * hash + (int) (Double.doubleToLongBits(this.saldoCuenta) ^ (Double.doubleToLongBits(this.saldoCuenta) >>> 32));
        hash = 47 * hash + Objects.hashCode(this.titularCuenta);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cuenta other = (Cuenta) obj;
        if (this.numeroCuenta != other.numeroCuenta) {
            return false;
        }
        if (Double.doubleToLongBits(this.saldoCuenta) != Double.doubleToLongBits(other.saldoCuenta)) {
            return false;
        }
        if (!Objects.equals(this.titularCuenta, other.titularCuenta)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cuenta{" + "numeroCuenta=" + numeroCuenta + ", saldoCuenta=" + saldoCuenta + ", titularCuenta=" + titularCuenta + '}';
    }
    
    
    
}
