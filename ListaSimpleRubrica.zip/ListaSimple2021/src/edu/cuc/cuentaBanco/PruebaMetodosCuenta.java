
package edu.cuc.cuentaBanco;

/**
 *
 * @author slayk
 */
public class PruebaMetodosCuenta {
    public static void main(String[] args) {
        
        MetodosCuenta cuenta01 = new MetodosCuenta("cuenta 01");
        //metodo adicionar
        cuenta01.adicionarCuenta(0, 00.0, "num0");
        cuenta01.adicionarCuenta(1, 10.0, "num1");
        cuenta01.adicionarCuenta(2, 20.0, "num2");
        cuenta01.adicionarCuenta(3, 30.0, "num3");
        cuenta01.adicionarCuenta(4, 40.0, "num4");
        cuenta01.adicionarCuenta(5, 50.0, "num5");
        System.out.println(cuenta01);
        
//        MetodosCuenta cuenta02 = new MetodosCuenta("cuenta 02");
//        cuenta02.adicionarCuenta(5, 50.0, "num5");
//        cuenta02.adicionarCuenta(2, 20.0, "num2");
//        cuenta02.adicionarCuenta(6, 60.0, "num6");
//        System.out.println(cuenta02);
//        //metodo buscar
//        System.out.println("buscar la cuenta 1: "+cuenta01.buscarCuenta(1));
//        //metodo eliminar
//        System.out.println("eliminar la cuenta 0: "+cuenta01.eliminarCuenta(0));
//        System.out.println(cuenta01);
//        //metodo indicar titular de la cuenta
//        System.out.println("la cuenta de cesar, num2 es: "+cuenta01.indicarCuentaTitular("num2"));
//        //metodo indicar sado de la cuenta
//        System.out.println("las cuenta con el saldo de 40.0 son: "+cuenta01.indicarCuentaSaldo(40.0));
//        //metodo indicar numero de la cuenta
//        System.out.println("las cuenta con el numero de 3 son: "+cuenta01.indicarCuentaNumero(3));
//        //metodo indicar promedio de la cuenta
//        System.out.println("el promedio de las cuenta es: "+cuenta01.indicarPromedioSaldo());
//        //metodo indicar saldo mayor
//        System.out.println("el saldo mayor es: "+cuenta01.indicarMayorSaldo());
//        //metodo indicar cuenta con mayor y menor saldo
//        System.out.println("la cuenta con mayor saldo es: "+cuenta01.indicarMayorSaldo());
//        System.out.println("la cuenta con menor saldo es: "+cuenta01.indicarMenorSaldo());
//        //metodo que muestra todas las cuenta menos la dicha por el usuario
//        System.out.println("todas menos la dada: "+cuenta01.indicarTodasMenosLaDada(2));
//        System.out.println(cuenta01);
//        //metodo para eliminar el mayor saldo de la cuenta
//        System.out.println("eliminar el mayor: "+cuenta01.eliminarMayorSaldo());
//        System.out.println(cuenta01);
//        System.out.println("eliminar el menor: "+cuenta01.eliminarMenorSaldo());
//        System.out.println(cuenta01);
//        //metodo que indica los iguales entre 2 cuenta banco
//        System.out.println("cuenta 1 y 2 son iguales: "+cuenta01.indicarIgualesDosBancos(cuenta02));
//        //metodo que indica los diferente entre 2 cuenta banco
//        System.out.println("cuenta 1 y 2 son diferente: "+cuenta01.indicarDiferenteDosBancos(cuenta02));
//        //metodo indicar ultimas y primeras cuentas 
//        System.out.println(cuenta01.indicarUltimasyPrimeras());
//        //metodo eliminar ultimas
//        System.out.println("se elimino las ultimas: "+cuenta01.eliminarUltima());;
//        System.out.println(cuenta01);
//        //metodo eliminar primeras
//        System.out.println("se elimino las primeras: "+cuenta01.eliminarPrimeras());
//        System.out.println(cuenta01);
//        //metodo eliminar todas las ceunta de un titular dado
//        cuenta01.eliminarCuentaTitularTodas("num3");
//        System.out.println(cuenta01);
//        //metodo eliminar todas las cuenta de un titular dado version 2
//        System.out.println("eliminar todas las cuenta de titular num3: "+cuenta01.eliminarCuentaTitularV2("num3"));
//        System.out.println(cuenta01);
//        //metodo que elimina por un rango max y un rango min dado por el usuario
//        System.out.println("eliminar la de un rango min y max: "+cuenta01.eliminarRangoSaldo(25.0, 45.0));
//        System.out.println(cuenta01);


    }
    
}
