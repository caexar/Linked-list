
package edu.cuc.pruebasNew;

import edu.cuc.listas.ListaSimple;

/**
 *
 * @author slayk
 */
public class PruebaTallerDiseño02 {
    public static void main(String[] args) {
         ListaSimple<Integer>listaEntero = new ListaSimple<>();
        //llenar los nodos 
        listaEntero.adicionarAlInicio(6);
        listaEntero.adicionarAlInicio(5);
        listaEntero.adicionarAlInicio(3);
        listaEntero.adicionarAlInicio(3);
        listaEntero.adicionarAlInicio(1);
        listaEntero.adicionarAlInicio(3);
        System.out.println(listaEntero);
        //metodo que da el último elemento de la lista (búsqueda).
        System.out.println("el ultimo elemento de la lista es: "+listaEntero.ultimoDatoDeLaLista());
        //metodo que da el penultimo elemento de la lista (búsqueda).
        System.out.println("el penultimo elemento de la lista es: "+listaEntero.penultimoDatoDeLaLista());
        //metodo que Indica los elementos entre dos posiciones (inicial y final, siendo inicial <final) de la lista.
        System.out.println("los elementos entre son: "+listaEntero.elementoEntreInicialFinalDeLaLista(1, 6));
        System.out.println(listaEntero);
        //elimar un elemento
        listaEntero.eliminar(5);
        System.out.println(listaEntero);     
        //eliminar todos los elementos iguales 
        listaEntero.eliminarTodasPisiciones(3);
        System.out.println(listaEntero);
        listaEntero.eliminarPosicion(2);
        System.out.println(listaEntero);
    }
    
}
