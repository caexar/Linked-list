
package edu.cuc.pruebasNew;

import edu.cuc.listas.ListaSimple;

/**
 *
 * @author slayk
 */
public class PruebaTallerDiseño03 {
    public static void main(String[] args) {
        ListaSimple<Integer>listaEntero = new ListaSimple<>();
        //llenar los nodos 
        listaEntero.adicionarAlInicio(1);
        listaEntero.adicionarAlInicio(2);
        listaEntero.adicionarAlInicio(3);
        listaEntero.adicionarAlInicio(3);
        listaEntero.adicionarAlInicio(4);
        listaEntero.adicionarAlInicio(5);
        System.out.println(listaEntero);
        System.out.println("posicion en la lista de 1 es: "+listaEntero.posicionEnLaLista(1));
        //metodo de apariciones y apariciones consecutiva
        System.out.println("el numero de apariciones normal de 1 es: "+listaEntero.numeroApariciones(1));
        System.out.println("el numero de apariciones consecutiva de 1 es: "+listaEntero.numeroAparicionesConsecutivas(1));
        System.out.println("el numero de apariciones normal de 3 es: "+listaEntero.numeroApariciones(3));
        System.out.println("el numero de apariciones consecutiva de 3 es: "+listaEntero.numeroAparicionesConsecutivas(3));
        //metodo para invertir la lista
        System.out.println("lista sin invertir: "+listaEntero);
        System.out.println("lista invertida:    "+listaEntero.invertirLaLista());
        System.out.println(listaEntero);
        //metodo desplazar de izqueirda a derecha
        listaEntero.desplazarLaListaIzquierdaADerecha();
        System.out.println(listaEntero);
        //metodo Mover un elemento desde una posición inicial, a una posición final de la lista.
        listaEntero.moberPosicionIniciaFinalDeLaLista(2, 4);
        System.out.println("la lista se mobio: "+listaEntero);
    }
    
}
