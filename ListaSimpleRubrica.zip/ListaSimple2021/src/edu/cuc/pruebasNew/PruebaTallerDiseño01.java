
package edu.cuc.pruebasNew;

import edu.cuc.listas.Lista;
import edu.cuc.listas.ListaSimple;

/**
 *
 * @author slayk
 */
public class PruebaTallerDiseño01 {
    public static void main(String[] args) {
        ListaSimple<Integer>listaEntero = new ListaSimple<>();
        //llenar los nodos 
        listaEntero.adicionarAlInicio(5);
        listaEntero.adicionarAlInicio(4);
        listaEntero.adicionarAlInicio(3);
        listaEntero.adicionarAlInicio(30);
        listaEntero.adicionarAlInicio(3);
        listaEntero.adicionarAlInicio(2);
        //metodo agregar al final 
        listaEntero.adicionarAlFinal(1);
        System.out.println(listaEntero);
        //metodos eliminar inicio y final
        listaEntero.eliminarAlInicio();
        listaEntero.eliminarAlFinal();
        System.out.println(listaEntero);
        //metodo numero de apariciones
        System.out.println("el numero de apariciones es: "+listaEntero.numeroApariciones(3));
        //metodo que idnica la posicion en la que aparece un dato en la lista
        System.out.println("la posicion es: "+listaEntero.posicionEnLaLista(30));
        //metodo que da el último elemento de la lista (búsqueda).
        System.out.println("el ultimo elemento de la lista es: "+listaEntero.ultimoDatoDeLaLista());
        System.out.println("posicion"+listaEntero.buscarPorPosicion(5));
    }
    
}
