package edu.cuc.listas;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

/**
 * Implementación Lista Simple
 *
 * @author adelahoz6
 */
public class ListaSimple<E> implements Lista<E>, Serializable {

    protected NodoSimple<E> nodoInicial;

    /**
     * Adicionar dato al inicio
     *
     * @param elemento
     */
    
    public void adicionarAlInicio(E elemento) {
        NodoSimple<E> nodoNuevo = new NodoSimple<>(elemento);
        if (estaVacia()) {
            //Caso Lista Vacia
            nodoInicial = nodoNuevo;
        } else {
            //Caso con al menos un elemento en la lista            
            nodoNuevo.siguiente = nodoInicial; //nodoNuevo -> nodoInicial
            nodoInicial = nodoNuevo;
        }
    }

 
    @Override
    public E eliminarAlInicio() {
        if (estaVacia()) {
            //Caso Lista Vacia
            return null;
        } else {
            //Caso lista con elementos
            E dato = nodoInicial.dato;
            nodoInicial = nodoInicial.siguiente; //nodoInicial -> nodoInicial
            return dato;
        }
    }
    
    public void adicionarAlFinal(E elemento) {
        NodoSimple<E> nodoNuevo = new NodoSimple<>(elemento);
        if (estaVacia()) {
            //Caso Lista Vacia
            nodoInicial = nodoNuevo;
        } else {
            NodoSimple<E> actual = nodoInicial;
            while (actual.getSiguiente() != null) { 
                actual = actual.siguiente;
            }
            actual.siguiente = nodoNuevo;          
           
        }
    }
    
    public boolean eliminarAlFinal() {
        if (estaVacia()) {
            //Caso Lista Vacia
            return false;
        } else {
            NodoSimple<E> actual = nodoInicial;
            NodoSimple<E> previo = null;
            while (actual.getSiguiente() != null) {  
                previo = actual;
                actual = actual.siguiente;
                 
            }
            previo.siguiente = null;
             //nodoInicial -> nodoInicial
            return true;
        }
    }
    //numero de apariciones en la lista
    public int numeroApariciones(E datoAContar) {
        int contador = 0;
        if (estaVacia()) {
            //Caso Lista Vacia
            return 0;
        } else {
             NodoSimple<E> actual = nodoInicial;
            while (actual != null) {
                if (actual.dato.equals(datoAContar)) {
                    contador++;
                }
                actual = actual.siguiente;
                
            }return contador;
        } 
    }
    //posiciones en las que aparece un dato en la lista.
    public int posicionEnLaLista(E datoAContar) {
        int contador = 0;
        if (estaVacia()) {
            //Caso Lista Vacia
            return 0;
        } else {
             NodoSimple<E> actual = nodoInicial;
            while (actual != null) {
                contador++;
                if (actual.dato.equals(datoAContar)) {
                    return contador;
                }
                actual = actual.siguiente;
                
            }return contador;
        } 
    }
    
    @Override
    public boolean buscar(E datoABuscar) {
        //Caso Lista Vacia
        if (estaVacia()) {
            return false;
        } else {
            //Caso lista con elementos
            NodoSimple<E> actual = nodoInicial;
            while (actual != null) {
                if (actual.dato.equals(datoABuscar)) {
                    return true;
                }
                actual = actual.siguiente;
            }
            return false;
        }
    }
    
    //el último elemento de la lista (búsqueda
    public E ultimoDatoDeLaLista() {
        if (estaVacia()) {
            //Caso Lista Vacia
            return null;
        } else {
            NodoSimple<E> actual = nodoInicial;
            while (actual.getSiguiente() != null) { 
                actual = actual.siguiente;
            }
             E dato = actual.dato;
                    
           return dato;
        }
    }
    
    //el penultimo elemento de la lista (búsqueda
    public E penultimoDatoDeLaLista() {
        if (estaVacia()) {
            //Caso Lista Vacia
            return null;
        } else {
            NodoSimple<E> actual = nodoInicial;
            NodoSimple<E> previo = null;
            while (actual.getSiguiente() != null) { 
                previo = actual;
                actual = actual.siguiente;
            }
             E dato = previo.dato;
                    
           return dato;
        }
    }
    
    //Indicar los elementos entre dos posiciones (inicial y final, siendo inicial <final) de la lista.
    public ArrayList<E> elementoEntreInicialFinalDeLaLista(int inicio, int fin){
        if(estaVacia()){
         throw new IndexOutOfBoundsException("esta vacia ");
        }else{
        ArrayList <E>list = new ArrayList<>();
        NodoSimple<E> actual = nodoInicial;
        int contador =0;
            while (actual != null) {                
                contador++;
                if (contador > inicio && fin > contador) {
                    list.add(actual.dato);
                }
                actual = actual.siguiente;
            }
            return list;
            
        }
    }

    /**
     * Indica si la lista está vacía
     *
     * @return
     */
    @Override
    public boolean estaVacia() {
        return nodoInicial == null;
    }

    /**
     * Elimina todos los elementos de la lista
     */
    @Override
    public void limpiar() {
        nodoInicial = null;
    }

    /**
     * Indica la cantidad de elementos en la lista
     *
     * @return
     */
    @Override
    public int longitud() {
        NodoSimple<E> actual = nodoInicial;
        int contador = 0;
        while (actual != null) {
            actual = actual.siguiente;
            contador++;
        }
        return contador;
    }

    @Override
    public String toString() {
        String info = "";
        NodoSimple<E> actual = nodoInicial;
        while (actual != null) {
            info += actual.dato + " ";
            actual = actual.siguiente;
        }
        return info;
    }

    /**
     * Método para buscar un elemento por posición
     *
     * @param posicion la posición del elemento a buscar, si existe
     * @return
     */
    @Override
    //no sirve
    public E buscarPorPosicion(int posicion) {
        if (estaVacia() || posicion < 0) {
            throw new IndexOutOfBoundsException("Indice: " + posicion);
        } else {
            NodoSimple<E> actual = nodoInicial;
            int contador = 0;
            while (actual != null && contador < posicion) {
                contador++;
                actual = actual.siguiente;
            }
            if (actual == null) {
                return null; //NO existe la posición 
            } else {
                return actual.dato;
            }
        }
    }
    
    //Indicar el número de veces consecutivas que aparece un dato indicado en una lista; modificado para que sea interno
    public int numeroAparicionesConsecutivas(E datoAContar) {
        int contador = 0;
        if (estaVacia()) {
            //Caso Lista Vacia
            return 0;
        } else {
            int contadorGuardado = 0;
            NodoSimple<E> actual = nodoInicial;
            while (actual != null) {
                if (actual.dato.equals(datoAContar)) {
                    contador++;
                    if (contador >= 2) {
                        contadorGuardado = contador;
                    }
                } else {
                    contador = 0;
                }
                actual = actual.siguiente;
            }
            return contadorGuardado;
        } 
    }
    
    //metodo Obtener la versión invertida de una lista dada.
    public ListaSimple invertirLaLista() {
        if (estaVacia()) {
            //Caso Lista Vacia
            ListaSimple<E> listaVacia = new ListaSimple<>();
            return listaVacia;
        } else {
            NodoSimple<E> actual = nodoInicial;
            ListaSimple<E> listaInvertida = new ListaSimple();
            int contador = 0;
            while (actual != null) {
                if (contador <= longitud()) {
                    listaInvertida.adicionarAlInicio(actual.dato);
                }
                contador++;
                actual = actual.siguiente;
            }
            return listaInvertida;
        }
    }
    
    //Desplazar la lista de izquierda a derecha una vez.
    //mober la lista a la derecha debo eliminar el ultimo dato y guardarlo en una variable y luego añado al iincio
    public boolean  desplazarLaListaIzquierdaADerecha() {
        if (estaVacia()) {
            //Caso Lista Vacia
            return false;
        } else {
            NodoSimple<E> actual = nodoInicial;
            NodoSimple<E> previo = null;
            NodoSimple<E> temporal = null;
            while (actual.getSiguiente() != null) {  
                previo = actual;
                actual = actual.siguiente;
                 
            }
            temporal = previo.siguiente;
            previo.siguiente = null;
             //nodoInicial -> nodoInicial
             adicionarAlInicio(temporal.dato);
            return true;
        }
    }
    
    /**
     * Método para eliminar un elemento por información
     *
     * @param dato el elemento a eliminar
     * @return
     */
    @Override
    //elimina un elemento solo 1, ojo
    public boolean eliminar(E dato) {
        //Lista Vacia
        if (estaVacia()) {
            return false;
        } else {
            //Nodo Inicial
            if (nodoInicial.dato.equals(dato)) {
                eliminarAlInicio();
                return true;
            } else {
                //Busqueda de información
                NodoSimple<E> previo = null;
                NodoSimple<E> actual = nodoInicial;
                while (actual != null && !actual.dato.equals(dato)) {
                    previo = actual;
                    actual = actual.siguiente;
                }
                //Caso Dato no encontrado
                if (actual == null) {
                    return false;
                } else {
                    //Caso Dato Encontrado
                    if (actual.siguiente == null) {
                        //Dato se encuentra en el ultimo nodo
                        previo.siguiente = null;
                        return true;
                    } else {
                        //Caso Nodo Intermedio
                        previo.siguiente = actual.siguiente;
                        return true;
                    }
                }
            }
        }
    }
    
    //Eliminar todas las apariciones de un dato en la lista tiene fallos
    public boolean eliminarTodasV1(E datoAEliminar) {
        //Lista Vacia
        if (estaVacia()) {
            return false;
        } else {
            NodoSimple<E> actual = nodoInicial;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
                
                if (nodoInicial.dato.equals(nodoInicial)) {
                eliminarAlInicio();
            } else 
                if (actual.dato.equals(datoAEliminar)) {
                    eliminar(datoAEliminar);
  
                }
                
            }
            return true;
        }
    }
    
    //eliminar en todas 100%
    public boolean eliminarTodasPisiciones(E datoEliminar){
        if (estaVacia()) {
            return false;
        } else {
            NodoSimple<E> previo = null;
            NodoSimple<E> actual = nodoInicial;
            
            while (actual != null) {                
                if (actual.dato.equals(datoEliminar)) {
                    if (nodoInicial.equals(actual)) {
                        nodoInicial = nodoInicial.siguiente;
                        
                        actual = nodoInicial;
                    
                }else {
                    previo.siguiente = actual.siguiente;
                    actual = actual.siguiente;
                }
            }else{
                    previo = actual;
                    actual = actual.siguiente;
                }
            }
            return true;
        }
    }
    
    //eliminar por posicion; si se repite el numero en otra posicion se borrara ese ojo!
    public  boolean eliminarPosicion (E posicion){
        int contador = 0;
        if (estaVacia()) {
            //Caso Lista Vacia
            return false;
        } else {
             NodoSimple<E> actual = nodoInicial;
            while (actual != null) {
                contador++;
                if (posicion.equals(contador)) {
                    eliminar(actual.dato);
                    return true;
                }
                actual = actual.siguiente;
                
            }return true;
        } 
    }
    //no sirve falta adicionar; nomas borra pero no agrega el dato
    //Mover un elemento desde una posición inicial, a una posición final de la lista.
    public  boolean moberPosicionIniciaFinalDeLaLista (int inicial, int fin){
        int contador = 0;
        if (estaVacia()) {
            //Caso Lista Vacia
            return false;
        } else {
            
             NodoSimple<E> actual = nodoInicial;
             NodoSimple<E> guardar = nodoInicial;
            while (actual != null) {
                contador++;
                if (inicial == contador) {
                    guardar = actual;
                    eliminar(actual.dato);
                }
                actual = actual.siguiente;
                if(fin == contador){
                    actual = guardar;
                    actual.siguiente = actual;
                    return true;
                }
            }System.out.println("salio ");return true;
        } 
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.nodoInicial);
        return hash;
    }

    /**
     * Clase Nodo Simple
     */
    protected class NodoSimple<E> implements Serializable {

        E dato;
        NodoSimple<E> siguiente;

        public NodoSimple(E dato) {
            this.dato = dato;
        }

        public E getDato() {
            return dato;
        }

        public void setDato(E dato) {
            this.dato = dato;
        }

        public NodoSimple<E> getSiguiente() {
            return siguiente;
        }

        public void setSiguiente(NodoSimple<E> siguiente) {
            this.siguiente = siguiente;
        }

        @Override
        public int hashCode() {
            int hash = 3;
            hash = 89 * hash + Objects.hashCode(this.dato);
            hash = 89 * hash + Objects.hashCode(this.siguiente);
            return hash;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final NodoSimple<?> other = (NodoSimple<?>) obj;
            if (!Objects.equals(this.dato, other.dato)) {
                return false;
            }
            return true;
        }

        @Override
        public String toString() {
            return dato.toString();
        }

    }

    /**
     * Método para serializar la instancia actual de la lista
     *
     * @param nombreArchivo
     * @throws FileNotFoundException
     * @throws IOException
     */
    public void guardar(String nombreArchivo) throws FileNotFoundException, IOException {
        FileOutputStream fileOutput = new FileOutputStream(nombreArchivo);
        ObjectOutputStream objectOutput = new ObjectOutputStream(fileOutput);
        objectOutput.writeObject(this);
        objectOutput.close();
        fileOutput.close();
    }

    /**
     * Método para deserializar una lista
     *
     * @param nombreArchivo
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static ListaSimple abrir(String nombreArchivo) throws
            FileNotFoundException, IOException, ClassNotFoundException {
        FileInputStream fileInput = new FileInputStream(nombreArchivo);
        ObjectInputStream objectInput = new ObjectInputStream(fileInput);
        ListaSimple listaLeida = (ListaSimple) objectInput.readObject();
        return listaLeida;
    }

}
