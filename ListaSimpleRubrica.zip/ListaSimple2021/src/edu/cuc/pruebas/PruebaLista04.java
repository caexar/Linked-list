package edu.cuc.pruebas;


import edu.cuc.listas.ListaSimple;


/**
 *
 * @author adelahoz6
 */
public class PruebaLista04 {
    public static void main(String[] args) {
        ListaSimple<String> listaCadenas = new ListaSimple<>();
        for (int i = 0; i < 1000; i++) {
            listaCadenas.adicionarAlInicio(i+"");
        }
//        listaCadenas.adicionarAlInicio("Java");
//        listaCadenas.adicionarAlInicio("Python");
//        listaCadenas.adicionarAlInicio("C++");
//        listaCadenas.adicionarAlInicio("Ruby");
//        listaCadenas.adicionarAlInicio("PHP");
        System.out.println(listaCadenas);
        System.out.println("Busqueda: "+listaCadenas.buscarPorPosicion(3));
        System.out.println("Busqueda: "+listaCadenas.buscarPorPosicion(0));
        System.out.println("Busqueda: "+listaCadenas.buscarPorPosicion(15));
        for (int i = 0; i < listaCadenas.longitud(); i++) {
            System.out.println("i:"+i+" = "+listaCadenas.buscarPorPosicion(i));
            
        }
    }
}
