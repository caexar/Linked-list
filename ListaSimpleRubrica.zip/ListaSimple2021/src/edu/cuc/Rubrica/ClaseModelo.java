
package edu.cuc.Rubrica;

import java.util.Objects;

/**
 *
 * @author cceveric
 */
public class ClaseModelo {
    private int codigo;
    private String nombre; 
    private double nota1, nota2, nota3, nota4, nota5;

    public ClaseModelo(int codigo, String nombre, double nota1, double nota2, double nota3, double nota4, double nota5) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
        this.nota4 = nota4;
        this.nota5 = nota5;
    }

  
    
    //getter y setter

    public int getCodigo() {
        return codigo;
    }

    public void setCódigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getNota1() {
        return nota1;
    }

    public void setNota1(double nota1) {
        this.nota1 = nota1;
    }

    public double getNota2() {
        return nota2;
    }

    public void setNota2(double nota2) {
        this.nota2 = nota2;
    }

    public double getNota3() {
        return nota3;
    }

    public void setNota3(double nota3) {
        this.nota3 = nota3;
    }

    public double getNota4() {
        return nota4;
    }

    public void setNota4(double nota4) {
        this.nota4 = nota4;
    }

    public double getNota5() {
        return nota5;
    }

    public void setNota5(double nota5) {
        this.nota5 = nota5;
    }
    
    //toString

    @Override
    public String toString() {
        return "ClaseModelo{" + "codigo=" + codigo + ", nombre=" + nombre + ", nota1=" + nota1 + ", nota2=" + nota2 + ", nota3=" + nota3 + ", nota4=" + nota4 + ", nota5=" + nota5 + '}';
    }

    
    //equals
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 29 * hash + this.codigo;
        hash = 29 * hash + Objects.hashCode(this.nombre);
        hash = 29 * hash + (int) (Double.doubleToLongBits(this.nota1) ^ (Double.doubleToLongBits(this.nota1) >>> 32));
        hash = 29 * hash + (int) (Double.doubleToLongBits(this.nota2) ^ (Double.doubleToLongBits(this.nota2) >>> 32));
        hash = 29 * hash + (int) (Double.doubleToLongBits(this.nota3) ^ (Double.doubleToLongBits(this.nota3) >>> 32));
        hash = 29 * hash + (int) (Double.doubleToLongBits(this.nota4) ^ (Double.doubleToLongBits(this.nota4) >>> 32));
        hash = 29 * hash + (int) (Double.doubleToLongBits(this.nota5) ^ (Double.doubleToLongBits(this.nota5) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ClaseModelo other = (ClaseModelo) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        if (Double.doubleToLongBits(this.nota1) != Double.doubleToLongBits(other.nota1)) {
            return false;
        }
        if (Double.doubleToLongBits(this.nota2) != Double.doubleToLongBits(other.nota2)) {
            return false;
        }
        if (Double.doubleToLongBits(this.nota3) != Double.doubleToLongBits(other.nota3)) {
            return false;
        }
        if (Double.doubleToLongBits(this.nota4) != Double.doubleToLongBits(other.nota4)) {
            return false;
        }
        if (Double.doubleToLongBits(this.nota5) != Double.doubleToLongBits(other.nota5)) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        return true;
    }

    
    
}
