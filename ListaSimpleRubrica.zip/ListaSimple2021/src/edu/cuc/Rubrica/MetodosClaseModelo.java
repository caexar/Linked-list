
package edu.cuc.Rubrica;

import edu.cuc.cuentaBanco.Cuenta;
import edu.cuc.listas.ListaSimple;
import java.util.ArrayList;

/**
 *
 * @author cceveric
 */
public class MetodosClaseModelo {
    
    private String nombreLista;
    private ListaSimple<ClaseModelo> listaCuenta = new ListaSimple<>();

    public MetodosClaseModelo(String nombreLista) {
        this.nombreLista = nombreLista;
    }

    public String getNombreLista() {
        return nombreLista;
    }

    public void setNombreLista(String nombreLista) {
        this.nombreLista = nombreLista;
    }

    @Override
    public String toString() {
        return "MetodosClaseModelo{" + "nombreLista=" + nombreLista + ", listaCuenta=" + listaCuenta + '}';
    }

    
    
    //metodo adicionar
    public boolean adicionarCuenta(int codigo, String nombre, double nota1, double nota2, double nota3, double nota4, double nota5){
        ClaseModelo cuentaNueva = new ClaseModelo(codigo, nombre, nota1, nota2, nota3, nota4, nota5);
        listaCuenta.adicionarAlInicio(cuentaNueva);
        return true;
    }
    
    //metodo buscar
    public boolean buscarCuenta(int codigo) {
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            ClaseModelo cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (cuentaNueva.getCodigo()== codigo) {
                return true;
            }
        }
        return false;
    }
    
    //metodo eliminar
    public boolean eliminarCuenta(int codigo) {
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            ClaseModelo cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (cuentaNueva.getCodigo()== codigo) {
                return listaCuenta.eliminar(cuentaNueva);
            }
        }
        return false;
    }
    
    //metodos 
    //Indicar los estudiantes con un promedio especificado por el usuario.
    public ArrayList<String> indicarPromedioDado(double promedioDado) {
        ArrayList<String> resultadousuario = new ArrayList<>();
        double promedio = 0.0;
        double promedioResultado;
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            ClaseModelo cuentaNueva = listaCuenta.buscarPorPosicion(i);
            promedio = cuentaNueva.getNota1() + cuentaNueva.getNota2() + cuentaNueva.getNota3() + cuentaNueva.getNota4() + cuentaNueva.getNota5();
            promedioResultado = promedio / 5;

            if (promedioResultado == promedioDado) {
                resultadousuario.add(cuentaNueva.getNombre());
            }
        }

        return resultadousuario;
}
    
    
    //Indicar los estudiantes que tengan dos notas o más aprobadas (mayores o iguales a 3.0).
    public ArrayList<String> indicarEstudianteCon2NotasAprobadas() {
        ArrayList<String> resultadousuario = new ArrayList<>();
        for (int i = 0; i < listaCuenta.longitud(); i++) {
            int contador =0;
            ClaseModelo cuentaNueva = listaCuenta.buscarPorPosicion(i);
            if (cuentaNueva.getNota1() >= 3.0) {
                contador++;
            } 
            if (cuentaNueva.getNota2() >= 3.0) {
                contador++;
            } 
            if (cuentaNueva.getNota3() >= 3.0) {
                contador++;
            } 
            if (cuentaNueva.getNota4() >= 3.0) {
                contador++;
            } 
            if (cuentaNueva.getNota5() >= 3.0) {
                contador++;
            }

            if (contador >= 2) {
                resultadousuario.add(cuentaNueva.getNombre());
            }
        }
        return resultadousuario;
    }

}
