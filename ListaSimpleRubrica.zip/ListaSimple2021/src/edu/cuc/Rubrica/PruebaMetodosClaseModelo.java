/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.Rubrica;

/**
 *
 * @author cceveric
 */
public class PruebaMetodosClaseModelo {
    public static void main(String[] args) {
        
        MetodosClaseModelo lista01 = new MetodosClaseModelo("lista01");
        lista01.adicionarCuenta(0, "estudiante0", 0.0, 0.0, 0.0, 0.0, 0.0);
        lista01.adicionarCuenta(1, "estudiante1", 5.0, 4.0, 3.0, 3.0, 5.0);
        lista01.adicionarCuenta(2, "estudiante2", 4.0, 4.0, 4.0, 4.0, 4.0);
        lista01.adicionarCuenta(3, "estudiante3", 1.0, 2.0, 3.0, 2.0, 1.0);
        lista01.adicionarCuenta(4, "estudiante4", 2.0, 4.0, 3.0, 2.5, 1.0);
        lista01.adicionarCuenta(5, "estudiante5", 1.0, 1.0, 0.0, 5.0, 1.0);
        System.out.println(lista01);
        System.out.println("se encontro el estudiante 2: "+lista01.buscarCuenta(1));
        System.out.println("se encontro el estudiante 3: "+lista01.buscarCuenta(2));
        System.out.println("se encontro el estudiante 5: "+lista01.buscarCuenta(5));
        System.out.println(lista01);
        System.out.println("eliminar la cuenta0: "+lista01.eliminarCuenta(0));
//        System.out.println("eliminar la cuenta1: "+lista01.eliminarCuenta(1));
        System.out.println("eliminar la cuenta5: "+lista01.eliminarCuenta(5));
        System.out.println(lista01);        
        System.out.println("el promedio de estudiante con promedio de 4.0 es: "+lista01.indicarPromedioDado(4.0));
        //metodo que indica si un estudiante tiene 2 notas paorbadas
        System.out.println("los estudiantes con dos o mas notas aprobadas son: "+lista01.indicarEstudianteCon2NotasAprobadas());
        
    }
    
}
