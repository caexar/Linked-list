package edu.cuc.metodosexternos;

import edu.cuc.listas.ListaSimple;

/**
 *
 * @author adelahoz6
 */
public class PruebaMetodosExternos01 {
    public static void main(String[] args) {
       //Creacion de la instancia Lista
        ListaSimple<Integer> listaPrueba = new ListaSimple<>();
        //Adicionar datos a la lista
        listaPrueba.adicionarAlInicio(9);
        listaPrueba.adicionarAlInicio(20);
        listaPrueba.adicionarAlInicio(80);
        listaPrueba.adicionarAlInicio(103);
        listaPrueba.adicionarAlInicio(1);
        listaPrueba.adicionarAlInicio(300);
        listaPrueba.adicionarAlInicio(10);
        listaPrueba.adicionarAlInicio(200);
        System.out.println(listaPrueba);
        //metodo para el mayor numero de la lista
        System.out.println("Mayor: "+MetodoExterno01.mayorLista(listaPrueba)); 
        System.out.println(" ");
        //metodo para comprobar si la lista tiene numeros aprtidiarios
        System.out.println("la lista es de numero partidiario es: "+MetodoExterno01.numeroPartidiario(listaPrueba));
        System.out.println(listaPrueba);
        System.out.println(" ");
            
        //lista n2
         ListaSimple<String> listaPrueba2 = new ListaSimple<>();
         listaPrueba2.adicionarAlInicio("palabra 1");
         listaPrueba2.adicionarAlInicio("palabra 2");
         listaPrueba2.adicionarAlInicio("palabra 3");
         listaPrueba2.adicionarAlInicio("palabra 2");
         listaPrueba2.adicionarAlInicio("palabra 2");
         listaPrueba2.adicionarAlInicio("palabra 1");
         listaPrueba2.adicionarAlInicio("palabra 1");
         listaPrueba2.adicionarAlInicio("palabra 1");
         
        //metodo para contar cuantas veces aparece una cadena
         System.out.println(listaPrueba2);
         System.out.println("numero de apariciones consecutiva de palabra 1: "+MetodoExterno01.vecesApareceUnaCadena(listaPrueba2, "palabra 1"));
         System.out.println("numero de apariciones consecutiva de palabra 2: "+MetodoExterno01.vecesApareceUnaCadena(listaPrueba2, "palabra 2"));
         System.out.println("numero de apariciones consecutiva de palabra 3: "+MetodoExterno01.vecesApareceUnaCadena(listaPrueba2, "palabra 3"));
    }
}
