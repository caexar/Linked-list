
package edu.cuc.metodosexternos;

import edu.cuc.listas.ListaSimple;
import java.util.ArrayList;

/**
 *
 * @author adelahoz6
 */
public class MetodoExterno01 {
    //Mayor de una lista de enteros
    public static int mayorLista(ListaSimple<Integer> lista) {
        int mayor = lista.buscarPorPosicion(0);
        for (int i = 0; i < lista.longitud(); i++) {
            int actual = lista.buscarPorPosicion(i);
            if (actual > mayor) {
                mayor = actual;
            }
        }
        return mayor;
    }
    //Indicar el número de veces consecutivas que aparece un dato indicado en
    //una lista de cadenas.
    public static int vecesApareceUnaCadena (ListaSimple<String> lista, String datoBuscar){
        int contador = 0;
        for (int i = 0; i < lista.longitud(); i++) {
          contador = lista.numeroAparicionesConsecutivas(datoBuscar);
            
        }
        return contador;
    }
    
    //Un arreglo de números se llama partidario si todo número que está en una
    //casilla par (0, 2, 4,…), es mayor que cualquiera de los números que están
    //en una casilla impar (1, 3, 5,…), indicar si una lista con números enteros
    //es partidaria o no.
    public static boolean numeroPartidiario(ListaSimple<Integer> lista){
        ArrayList<Integer> numPar = new ArrayList();
        ArrayList<Integer> numInpar = new ArrayList();
        int contador = -1;
        for (int i = 0; i < lista.longitud(); i++) {
            contador++;
            int actual = lista.buscarPorPosicion(i);
            if (contador % 2 == 0) {
                numPar.add(actual);
            } else {
                numInpar.add(actual);
            }
        }

        int contadorPar = 0;
        int contadorPosicion = 0;
//      System.out.println("numero par: "+numPar);
//      System.out.println("numero inpar: "+numInpar);
        for (int i = 0; i < numPar.size(); i++) {
            for (int j = 0; j < numInpar.size(); j++) {
//                System.out.println("el valor de par es: "+numPar.get(contadorPosicion));
                if (numPar.get(contadorPosicion) > numInpar.get(j)) {
//                  System.out.println("el numero par es: "+numPar.get(contadorPosicion)+"-  el numero inpar es: "+numInpar.get(j));
                    contadorPosicion++;
                    contadorPar++;
//                  System.out.println("numerp de contador "+contadorPosicion);
                    if (contadorPar >= numPar.size()) {
                        return true;
                    }
                } else {
                    contadorPar = 0;
                    return false;
                }
            }
        }
        return false;
    }
}
