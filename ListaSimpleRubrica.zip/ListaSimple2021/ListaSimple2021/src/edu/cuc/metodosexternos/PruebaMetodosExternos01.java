package edu.cuc.metodosexternos;

import edu.cuc.listas.ListaSimple;

/**
 *
 * @author adelahoz6
 */
public class PruebaMetodosExternos01 {
    public static void main(String[] args) {
        //Creacion de la instancia Lista
        ListaSimple<Integer> listaPrueba = new ListaSimple<>();
        //Adicionar datos a la lista
        listaPrueba.adicionarAlInicio(10);
        listaPrueba.adicionarAlInicio(-9);
        listaPrueba.adicionarAlInicio(20);
        listaPrueba.adicionarAlInicio(80);
        listaPrueba.adicionarAlInicio(103);
        System.out.println(listaPrueba);
        System.out.println("Mayor: "+MetodoExterno01.mayorLista(listaPrueba));
    }
}
