package edu.cuc.pruebas;

import edu.cuc.listas.ListaSimple;

/**
 *
 * @author adelahoz6
 */
public class PruebaLista05 {
    public static void main(String[] args) {
        ListaSimple<Integer> listaEnteros = new ListaSimple<>();
        listaEnteros.adicionarAlInicio(30);
        listaEnteros.adicionarAlInicio(3);
        listaEnteros.adicionarAlInicio(9);
        listaEnteros.adicionarAlInicio(10);
        listaEnteros.adicionarAlInicio(3);
        listaEnteros.adicionarAlInicio(2);
        System.out.println(listaEnteros);
        System.out.println("Eliminar: "+listaEnteros.eliminar(15));
        System.out.println(listaEnteros);
        System.out.println("Eliminar: "+listaEnteros.eliminar(3));
        System.out.println(listaEnteros);
        System.out.println("Eliminar: "+listaEnteros.eliminar(2));
        System.out.println(listaEnteros);
        System.out.println("Eliminar: "+listaEnteros.eliminar(30));
        System.out.println(listaEnteros);
    }
  
}
